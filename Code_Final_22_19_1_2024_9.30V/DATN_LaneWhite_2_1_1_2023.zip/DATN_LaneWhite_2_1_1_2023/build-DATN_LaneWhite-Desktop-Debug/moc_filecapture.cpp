/****************************************************************************
** Meta object code from reading C++ file 'filecapture.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../DATN_LaneWhite/filecapture.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'filecapture.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_FileCapture_t {
    QByteArrayData data[35];
    char stringdata0[483];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FileCapture_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FileCapture_t qt_meta_stringdata_FileCapture = {
    {
QT_MOC_LITERAL(0, 0, 11), // "FileCapture"
QT_MOC_LITERAL(1, 12, 16), // "newFrameCaptured"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 3), // "Mat"
QT_MOC_LITERAL(4, 34, 5), // "frame"
QT_MOC_LITERAL(5, 40, 12), // "newFrameLane"
QT_MOC_LITERAL(6, 53, 10), // "frame_lane"
QT_MOC_LITERAL(7, 64, 16), // "result_Processed"
QT_MOC_LITERAL(8, 81, 6), // "result"
QT_MOC_LITERAL(9, 88, 13), // "distance_stop"
QT_MOC_LITERAL(10, 102, 14), // "distance_uturn"
QT_MOC_LITERAL(11, 117, 21), // "distance_TrafficLight"
QT_MOC_LITERAL(12, 139, 18), // "destroy_controlCar"
QT_MOC_LITERAL(13, 158, 14), // "display_Result"
QT_MOC_LITERAL(14, 173, 4), // "Mat&"
QT_MOC_LITERAL(15, 178, 10), // "frameFinal"
QT_MOC_LITERAL(16, 189, 7), // "Capture"
QT_MOC_LITERAL(17, 197, 14), // "setting_camera"
QT_MOC_LITERAL(18, 212, 12), // "frame_camera"
QT_MOC_LITERAL(19, 225, 12), // "setting_wrap"
QT_MOC_LITERAL(20, 238, 15), // "frame_Pres_func"
QT_MOC_LITERAL(21, 254, 17), // "setting_ThreShold"
QT_MOC_LITERAL(22, 272, 15), // "frame_Thre_func"
QT_MOC_LITERAL(23, 288, 16), // "frame_final_func"
QT_MOC_LITERAL(24, 305, 18), // "setting_Histrogram"
QT_MOC_LITERAL(25, 324, 18), // "setting_LaneFinder"
QT_MOC_LITERAL(26, 343, 18), // "setting_LaneCenter"
QT_MOC_LITERAL(27, 362, 14), // "Stop_detection"
QT_MOC_LITERAL(28, 377, 12), // "rawFrameStop"
QT_MOC_LITERAL(29, 390, 15), // "UTurn_detection"
QT_MOC_LITERAL(30, 406, 13), // "rawFrameUTurn"
QT_MOC_LITERAL(31, 420, 20), // "TrafficRed_detection"
QT_MOC_LITERAL(32, 441, 18), // "rawFrameTrafficRed"
QT_MOC_LITERAL(33, 460, 10), // "openCamera"
QT_MOC_LITERAL(34, 471, 11) // "stopCapture"

    },
    "FileCapture\0newFrameCaptured\0\0Mat\0"
    "frame\0newFrameLane\0frame_lane\0"
    "result_Processed\0result\0distance_stop\0"
    "distance_uturn\0distance_TrafficLight\0"
    "destroy_controlCar\0display_Result\0"
    "Mat&\0frameFinal\0Capture\0setting_camera\0"
    "frame_camera\0setting_wrap\0frame_Pres_func\0"
    "setting_ThreShold\0frame_Thre_func\0"
    "frame_final_func\0setting_Histrogram\0"
    "setting_LaneFinder\0setting_LaneCenter\0"
    "Stop_detection\0rawFrameStop\0UTurn_detection\0"
    "rawFrameUTurn\0TrafficRed_detection\0"
    "rawFrameTrafficRed\0openCamera\0stopCapture"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FileCapture[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   99,    2, 0x06 /* Public */,
       5,    1,  102,    2, 0x06 /* Public */,
       7,    4,  105,    2, 0x06 /* Public */,
      12,    0,  114,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      13,    3,  115,    2, 0x0a /* Public */,
      16,    1,  122,    2, 0x0a /* Public */,
      17,    1,  125,    2, 0x0a /* Public */,
      19,    2,  128,    2, 0x0a /* Public */,
      21,    3,  133,    2, 0x0a /* Public */,
      24,    0,  140,    2, 0x0a /* Public */,
      25,    1,  141,    2, 0x0a /* Public */,
      26,    1,  144,    2, 0x0a /* Public */,
      27,    1,  147,    2, 0x0a /* Public */,
      29,    1,  150,    2, 0x0a /* Public */,
      31,    1,  153,    2, 0x0a /* Public */,
      33,    0,  156,    2, 0x0a /* Public */,
      34,    0,  157,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    8,    9,   10,   11,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 14, 0x80000000 | 14, QMetaType::Int,    4,   15,    8,
    QMetaType::Void, 0x80000000 | 14,    4,
    QMetaType::Void, 0x80000000 | 14,   18,
    QMetaType::Void, 0x80000000 | 14, 0x80000000 | 14,    4,   20,
    QMetaType::Void, 0x80000000 | 14, 0x80000000 | 14, 0x80000000 | 14,   20,   22,   23,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 14,   23,
    QMetaType::Void, 0x80000000 | 14,   23,
    QMetaType::Void, 0x80000000 | 14,   28,
    QMetaType::Void, 0x80000000 | 14,   30,
    QMetaType::Void, 0x80000000 | 14,   32,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void FileCapture::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FileCapture *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->newFrameCaptured((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 1: _t->newFrameLane((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 2: _t->result_Processed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 3: _t->destroy_controlCar(); break;
        case 4: _t->display_Result((*reinterpret_cast< Mat(*)>(_a[1])),(*reinterpret_cast< Mat(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 5: _t->Capture((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 6: _t->setting_camera((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 7: _t->setting_wrap((*reinterpret_cast< Mat(*)>(_a[1])),(*reinterpret_cast< Mat(*)>(_a[2]))); break;
        case 8: _t->setting_ThreShold((*reinterpret_cast< Mat(*)>(_a[1])),(*reinterpret_cast< Mat(*)>(_a[2])),(*reinterpret_cast< Mat(*)>(_a[3]))); break;
        case 9: _t->setting_Histrogram(); break;
        case 10: _t->setting_LaneFinder((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 11: _t->setting_LaneCenter((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 12: _t->Stop_detection((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 13: _t->UTurn_detection((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 14: _t->TrafficRed_detection((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 15: _t->openCamera(); break;
        case 16: _t->stopCapture(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FileCapture::*)(Mat );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FileCapture::newFrameCaptured)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FileCapture::*)(Mat );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FileCapture::newFrameLane)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FileCapture::*)(int , int , int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FileCapture::result_Processed)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (FileCapture::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FileCapture::destroy_controlCar)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject FileCapture::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_FileCapture.data,
    qt_meta_data_FileCapture,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *FileCapture::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FileCapture::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_FileCapture.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int FileCapture::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
    return _id;
}

// SIGNAL 0
void FileCapture::newFrameCaptured(Mat _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void FileCapture::newFrameLane(Mat _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void FileCapture::result_Processed(int _t1, int _t2, int _t3, int _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void FileCapture::destroy_controlCar()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
